﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Data;

namespace LibraryManagementSystem.Converters
{
    [ValueConversion(typeof(string), typeof(string))]
    public class StringConverter : IValueConverter
    {
        #region IValueConverter Members
        public string Text { get; set; }
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string str = "";
            if (value is DateTime dateTime)
            {
                str = dateTime.ToShortDateString();
            }
            else if (value is string temp)
            {
                str = temp;
            }
            else str = value.ToString();
            StringBuilder sb = new StringBuilder();
            sb.Append(Text + " "+str);
            return sb.ToString();

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        #endregion
    }
}
