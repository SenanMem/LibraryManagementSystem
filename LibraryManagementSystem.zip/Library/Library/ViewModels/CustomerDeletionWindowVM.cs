﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.CommandWpf;
using Library.SubEvent;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class CustomerDeletionWindowVM
    {
        public List<BookTransaction> BookHistory { get; private set; }
        public List<Customer> Customers { get; private set; }

        public Customer DeleteCustomer { get; private set; }

        public int Id { get; set; }

        private UnitOfWorkEntity UnitOfWork;

        public ICommand DeleteCustomerCmnd { get; set; }

        public IEventAggregator GetEventAggregator { get; set; }

        public event Action<object, RoutedEventArgs> CloseEvent;

        public CustomerDeletionWindowVM(ContextEntity _context, IEventAggregator getEventAggregator)
        {
            UnitOfWork = new UnitOfWorkEntity(_context);
            DeleteCustomerCmnd = new RelayCommand(DeleteCustomerMethod);
            GetEventAggregator = getEventAggregator;
            GetEventAggregator.GetEvent<HistorySendEvent>().Subscribe(HistorySendMethod);
            GetEventAggregator.GetEvent<CustomersSendEvent>().Subscribe(CustomerSendMethod);

        }

        private void CustomerSendMethod(List<Customer> customers)
        {
            Customers = customers;
        }

        private void HistorySendMethod(List<BookTransaction> bookHistory)
        {
            BookHistory = bookHistory;
        }

        private async void DeleteCustomerMethod()
        {
            List<BookTransaction> DeleteCustomerBookHistoryNotChekIn;
            if (BookHistory == null || BookHistory.Count == 0)
            {
                DeleteCustomerBookHistoryNotChekIn = null;
            }
            else
            {
                DeleteCustomerBookHistoryNotChekIn = BookHistory.FindAll(x => x.Customer.Id == Id && x.CheckOut != null && x.CheckIn == null);
            }
            if (DeleteCustomerBookHistoryNotChekIn != null)
            {
                MessageBox.Show("If the deleted customer has a non-refundable book, the return date will be recorded at the same time as the customer's deletion date", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                foreach (var item in DeleteCustomerBookHistoryNotChekIn)
                {
                    item.CheckIn = DateTime.Now;
                    item.Book.TotalCopies++;
                    item.Book.AvailableCopies--;
                }
            }
            bool IsDelete = false;
            foreach (var item in Customers)
            {
                if (item.Id == Id)
                {
                    DeleteCustomer = item;
                    IsDelete = true;
                    break;
                }
            }
            CloseEvent?.Invoke(new object(), new RoutedEventArgs());
            if (IsDelete == false) MessageBox.Show("There are no customers on this id", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            else
            {
                DeleteCustomer.IsActived = false;
                DeleteCustomer.DeleteDate = DateTime.Now;
                await UnitOfWork.CustomerRepository.UpdateAsync(DeleteCustomer);
                await UnitOfWork.ConmpleteAsync();
            }
        }
    }
}
