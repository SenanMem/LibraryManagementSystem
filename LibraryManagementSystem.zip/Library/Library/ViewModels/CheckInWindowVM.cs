﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.CommandWpf;
using Library.SubEvent;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace Library.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class CheckInWindowVM
    {
        public List<BookTransaction> BookHistory { get; private set; }

        public List<Customer> Customers { get; private set; }

        public BookTransaction UpdateBookTransaction { get; private set; }
        public int Id { get; set; }

        public Customer Customer { get; set; }

        private UnitOfWorkEntity UnitOfWork;

        public ICommand CheckInCmnd { get; set; }
        public IEventAggregator GetEventAggregator { get; set; }
        private Book _book { get; set; } = new Book();

        public event Action<object, RoutedEventArgs> CloseEvent;
        public CheckInWindowVM(ContextEntity _context, IEventAggregator getEventAggregator, Book book)
        {
            UpdateBookTransaction = new BookTransaction();
            UnitOfWork = new UnitOfWorkEntity(_context);
            CheckInCmnd = new RelayCommand(CheckInMethod);
            GetEventAggregator = getEventAggregator;
            GetEventAggregator.GetEvent<HistorySendEvent>().Subscribe(HistorySendMethod);
            GetEventAggregator.GetEvent<CustomersSendEvent>().Subscribe(CustomersSendMethod);
            _book = book;
        }
        private void CustomersSendMethod(List<Customer> customers)
        {
            Customers = customers;
        }

        private void HistorySendMethod(List<BookTransaction> bookHistory)
        {
            BookHistory = bookHistory;
        }


        private async void CheckInMethod()
        {

            if (BookHistory == null)
                UpdateBookTransaction = null;
            else
                UpdateBookTransaction = BookHistory.Find(x => x.IsActived == true && x.Book.Id == _book.Id && x.Customer.Id == Id && x.CheckOut!=null && x.CheckIn == null);

            if (Customers!=null && Customers.Find(x => x.Id == Id) != null)
            {
                if (UpdateBookTransaction != null)
                {
                    UpdateBookTransaction.Book.TotalCopies++;
                    UpdateBookTransaction.Book.AvailableCopies--;

                    CloseEvent?.Invoke(new object(), new RoutedEventArgs());
                    UpdateBookTransaction.CheckIn = DateTime.Now;
                    await UnitOfWork.BookRepository.UpdateAsync(UpdateBookTransaction.Book);
                    GetEventAggregator.GetEvent<BookAddUpdateEvent>().Publish(UpdateBookTransaction.Book);
                    UnitOfWork.BookTransactionRepository.Update(UpdateBookTransaction);
                    await UnitOfWork.ConmpleteAsync();
                    UpdateBookTransaction = null;
                }
                else
                {
                    MessageBox.Show("With the ID, the customer did not take this book.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                }

            }
            else
            {
                MessageBox.Show("There is no customer in this Id!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
