﻿using DataAccessLayer;
using Domains;
using Library.SubEvent;
using LibraryManagementSystem.ViewModels;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class BookHistoryWindowVM : BaseVM
    {
        public List<BookTransaction> BookHistory { get; set; }

        private UnitOfWorkDapper UnitOfWorkDp { get; set; }
        private Book _book { get; set; }

        public IEventAggregator GetEventAggregator { get; set; }


        public BookHistoryWindowVM(ContextDapper contextDapper, IEventAggregator eventAggregator, Book book)
        {
            _book = book;
            UnitOfWorkDp = new UnitOfWorkDapper(contextDapper);
            GetEventAggregator = eventAggregator;
            GetEventAggregator.GetEvent<HistorySendEvent>().Subscribe(HistorySendMethod);
        }
        private void HistorySendMethod(List<BookTransaction> bookHistory)
        {
            BookHistory = bookHistory;
        }
    }
}
