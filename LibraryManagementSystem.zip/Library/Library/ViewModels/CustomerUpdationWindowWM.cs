﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.CommandWpf;
using Library.SubEvent;
using Microsoft.Win32;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class CustomerUpdationWindowWM
    {
        public Customer UpdateCustomer { get; private set; }

        public List<Customer> Customers { get; set; }

        public int Id { get; set; }

        private UnitOfWorkEntity UnitOfWork;
        public int FetchDetailsHeight { get; set; } = 112;
        public int UpdateCustomerHeight { get; set; } = 0;
        public ICommand UpdateCustomerCmnd { get; set; }
        public ICommand FetchDetailsCmnd { get; set; }
        public IEventAggregator GetEventAggregator { get; set; }

        public event Action<object, RoutedEventArgs> CloseEvent;
        public CustomerUpdationWindowWM(ContextEntity _context, IEventAggregator getEventAggregator)
        {
            UpdateCustomer = new Customer();
            Customers = new List<Customer>();

            UnitOfWork = new UnitOfWorkEntity(_context);
            FetchDetailsCmnd = new RelayCommand(FetchDetailsCmndMethod);
            UpdateCustomerCmnd = new RelayCommand(UpdateCustomerMethod);
            GetEventAggregator = getEventAggregator;
            GetEventAggregator.GetEvent<CustomersSendEvent>().Subscribe(CustomersSendMethod);
        }

        private void CustomersSendMethod(List<Customer> customers)
        {
            Customers = customers;
        }

        private void FetchDetailsCmndMethod()
        {
            UpdateCustomer = Customers.Find(x => x.Id == Id);
            if (UpdateCustomer == null || UpdateCustomer.IsActived==false)
            {
                UpdateCustomer = null;
                MessageBox.Show("Not Data!!!", "Search ID", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                FetchDetailsHeight = 0;
                UpdateCustomerHeight = 311;
            }
        }

        private async void UpdateCustomerMethod()
        {
            if (UpdateCustomer != null && UpdateCustomer.IsActived==true)
            {
            CloseEvent?.Invoke(new object(), new RoutedEventArgs());
            UpdateCustomer.UpdateDate = DateTime.Now;
            await UnitOfWork.CustomerRepository.UpdateAsync(UpdateCustomer);
            await UnitOfWork.ConmpleteAsync();
            GetEventAggregator.GetEvent<CustomerAddUpdateEvent>().Publish(UpdateCustomer);
            UpdateCustomer = null;
            }
        }
    }
}
