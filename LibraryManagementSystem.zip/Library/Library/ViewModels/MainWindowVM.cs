﻿using DataAccessLayer;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class MainWindowVM : BaseVM
    {
        public BaseVM CurrentVM { get; set; }
        
        public MainWindowVM()
        {
            CurrentVM = new HomeVM(new ContextDapper(),new ContextEntity(),null);
        }

    }
}
