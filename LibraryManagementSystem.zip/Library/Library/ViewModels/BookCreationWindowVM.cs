﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.CommandWpf;
using Library.SubEvent;
using Microsoft.Win32;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class BookCreationWindowVM : BaseVM
    {
        public Book NewBook { get;private set; }

        private UnitOfWorkEntity  UnitOfWork;

        public BitmapImage bitmap { get; set; }

        public ICommand AddBookCmnd { get; set; }
        public ICommand AddImageCmnd { get; set; }

        public IEventAggregator GetEventAggregator { get; set; }


        public event Action<object, RoutedEventArgs> CloseEvent;

        public BookCreationWindowVM(ContextEntity _context, IEventAggregator getEventAggregator)
        {
            GetEventAggregator = getEventAggregator;
            UnitOfWork = new UnitOfWorkEntity(_context);
            NewBook = new Book();
            AddBookCmnd = new RelayCommand(AddBookMethod);
            AddImageCmnd = new RelayCommand(AddImageMethod);
        }

        private void AddImageMethod()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = "c:\\";
            dlg.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png | All Files (*.*)|*.*";
            dlg.RestoreDirectory = true;
            if (dlg.ShowDialog() == true)
            {
                string selectedFileName = dlg.FileName;
                NewBook.BookCover = GetImageBytes(selectedFileName);
                bitmap = ToImage(NewBook.BookCover);
            }
        }

        private BitmapImage ToImage(byte[] array)
        {
            using (var ms = new System.IO.MemoryStream(array))
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad; // here
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
        }

        private byte[] GetImageBytes(string imagePath)
        {
            return File.ReadAllBytes(imagePath);
        }

        private async void AddBookMethod()
        {
            GetEventAggregator.GetEvent<BookAddUpdateEvent>().Publish(NewBook);
            CloseEvent?.Invoke(new object(), new RoutedEventArgs());
            await UnitOfWork.BookRepository.AddAsync(NewBook);
            await UnitOfWork.ConmpleteAsync();
        }
    }
}
