﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.Command;
using Library.SubEvent;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class CheckOutWindowVM
    {
        public BookTransaction NewBookTransaction { get; private set; }
        public List<BookTransaction> BookHistory { get; private set; }
        public List<Customer> Customers { get; private set; }
        public int Id { get; set; }

        public Customer Customer { get; set; }

        private UnitOfWorkEntity UnitOfWork;

        public ICommand CheckOutCmnd { get; set; }
        public IEventAggregator GetEventAggregator { get; set; }

        public event Action<object, RoutedEventArgs> CloseEvent;
        public CheckOutWindowVM(ContextEntity _context, IEventAggregator getEventAggregator, Book book)
        {
            NewBookTransaction = new BookTransaction();
            UnitOfWork = new UnitOfWorkEntity(_context);
            CheckOutCmnd = new RelayCommand(CheckOutMethod);
            NewBookTransaction.Book = book;
            GetEventAggregator = getEventAggregator;
            GetEventAggregator.GetEvent<HistorySendEvent>().Subscribe(HistorySendMethod);
            GetEventAggregator.GetEvent<CustomersSendEvent>().Subscribe(CustomersSendMethod);
        }

        private void CustomersSendMethod(List<Customer> customers)
        {
            Customers = customers;
        }

        private void HistorySendMethod(List<BookTransaction> bookHistory)
        {
            BookHistory = bookHistory;
        }

        private async void CheckOutMethod()
        {
            CloseEvent?.Invoke(new object(), new RoutedEventArgs());

            if (Customers == null) 
                Customer = null;
            else
                Customer = Customers.Find(x => x.Id == Id) ?? null;

            if (Customer != null)
            {
                if (NewBookTransaction.Book.TotalCopies > 0)
                {
                    if (BookHistory.Count==0 || BookHistory.Find(x => x.Customer.Id == Id && x.Book.Id == NewBookTransaction.Book.Id && x.CheckOut != null && x.CheckIn == null) != null)
                    {
                        NewBookTransaction.Book.TotalCopies--;
                        NewBookTransaction.Book.AvailableCopies++;
                        NewBookTransaction.Customer = Customer;
                        NewBookTransaction.CheckOut = DateTime.Now;
                        GetEventAggregator.GetEvent<BookAddUpdateEvent>().Publish(NewBookTransaction.Book);
                        await UnitOfWork.BookRepository.UpdateAsync(NewBookTransaction.Book);
                        await UnitOfWork.ConmpleteAsync();
                        await UnitOfWork.BookTransactionRepository.AddAsync(NewBookTransaction);
                        await UnitOfWork.ConmpleteAsync();
                        NewBookTransaction = null;
                    }
                    else
                    {
                        MessageBox.Show("If the same Book is not returned, a new one cannot be given!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);

                    }
                }
                else
                {
                    MessageBox.Show("There are not enough copies of the selected book!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("There is no customer in this Id!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

    }
}
