﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.Command;
using Library.SubEvent;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class BookUpdationWindowVM:BaseVM
    {
        public Book SelectedBook { get; set; }

        private UnitOfWorkEntity UnitOfWork;

        public ICommand UpdateBookCmnd { get; set; }
        public ICommand CancelCmnd { get; set; }

        public IEventAggregator GetEventAggregator { get; set; }

        public event Action<object, RoutedEventArgs> CloseEvent;
        public BookUpdationWindowVM(ContextEntity context, IEventAggregator getEventAggregator, Book book)
        {
            
            SelectedBook = book;
            UnitOfWork = new UnitOfWorkEntity(context);
            UpdateBookCmnd = new RelayCommand(UpdateBookMethod);
            CancelCmnd = new RelayCommand(CancelMethod);
            GetEventAggregator = getEventAggregator;
        }

        private void CancelMethod()
        {
            SelectedBook = null;
        }

        private async void UpdateBookMethod()
        {
            if (SelectedBook != null && SelectedBook.IsActived == true)
            {
                CloseEvent?.Invoke(new object(), new RoutedEventArgs());
                SelectedBook.UpdateDate = DateTime.Now;
                await UnitOfWork.BookRepository.UpdateAsync(SelectedBook);
                await UnitOfWork.ConmpleteAsync();
                GetEventAggregator.GetEvent<BookAddUpdateEvent>().Publish(SelectedBook);
            }
            else
            {
                MessageBox.Show("Not Data!!!", "Search ID", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            SelectedBook = null;
        }
    }
}
