﻿using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class BaseVM
    {
        public BaseVM CurrentVM { get; set; }
    }
}
