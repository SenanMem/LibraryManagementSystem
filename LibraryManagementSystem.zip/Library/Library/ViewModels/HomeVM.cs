﻿using DataAccessLayer;
using Domains;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;
using Prism.Events;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using LibraryManagementSystem.Views;
using System.Windows;
using Library.SubEvent;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class HomeVM:BaseVM
    {
        public Book SelectedBook { get; set; }
        public List<Book> Books { get; set; }
        public List<Book> CopyBooks { get; set; }
        public List<Customer> Customers { get; set; } 
        public List<BookTransaction> BookHistory { get; set; } 

        private UnitOfWorkDapper UnitOfWorkDp { get; set; }
        private UnitOfWorkEntity UnitOfWorkEntity { get; set; }

        public IEventAggregator GetEventAggregator { get; set; }

        public ICommand DeleteBookCmnd { get; set; }
        public ICommand SearchBooksCmnd { get; set; }

        public event Action QueryEvent;


        private string query;
        public string Query
        {
            get
            {
                return query;
            }
            set
            {
                query = value;
                QueryEvent?.Invoke();
            }
        }


        public HomeVM(ContextDapper context, ContextEntity _context, IEventAggregator getEventAggregator)
        {
            if (getEventAggregator != null)
            {
            Books = new List<Book>();
            CopyBooks = new List<Book>();
            Customers = new List<Customer>();
            BookHistory = new List<BookTransaction>();

            DeleteBookCmnd = new RelayCommand(DeleteBookMethod);
            SearchBooksCmnd = new RelayCommand(SearchBooksMethods);

            GetEventAggregator = getEventAggregator;
            GetEventAggregator.GetEvent<BookAddUpdateEvent>().Subscribe(AddUpdateBook);
            GetEventAggregator.GetEvent<CustomerAddUpdateEvent>().Subscribe(AddUpdateCustomer);
            UnitOfWorkDp = new UnitOfWorkDapper(context);
            UnitOfWorkEntity = new UnitOfWorkEntity(_context);

            QueryEvent += HomeVM_SearchEvent;
            Load();
            }
        }
        private void AddUpdateCustomer(Customer customer)
        {
            List<Customer> temp = new List<Customer>();
            bool IsUpdate = false;
            foreach (var item in Customers)
            {
                if (item.Id == customer.Id)
                {
                    temp.Add(customer);
                    IsUpdate = true;
                }
                else
                temp.Add(item);
            }
            if (!IsUpdate)
                temp.Add(customer);

            Customers.Clear();
            Customers = temp;
        }


        private void SearchBooksMethods()
        {
            if (Query != string.Empty) 
            {
                List<Book> books = CopyBooks.Where(e => e.ToString().Contains(Query)).ToList();
                Books = books;
            }
        }

        private void HomeVM_SearchEvent()
        {
            if (Query == string.Empty) Books=CopyBooks;
        }



        private async void DeleteBookMethod()
        {
            if (SelectedBook == null)
            {
                MessageBox.Show("Not Data!!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                var DeleteBook_BookHistoryNotChekIn = BookHistory.FindAll(x => x.Book.Id==SelectedBook.Id && x.CheckOut != null && x.CheckIn == null);
                if (DeleteBook_BookHistoryNotChekIn != null)
                {
                    MessageBox.Show("If the deleted book has a non-refundable copy, the return date will be recorded at the same time as the deletion date of the book.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                    foreach (var item in DeleteBook_BookHistoryNotChekIn)
                    {
                        item.CheckIn = DateTime.Now;
                        item.Book.TotalCopies++;
                        item.Book.AvailableCopies--;
                    }
                }
                Books.Remove(SelectedBook);
                List<Book> temp = new List<Book>();
                foreach (var item in Books)
                {
                    temp.Add(item);
                }
                SelectedBook.IsActived = false;
                await UnitOfWorkEntity.BookRepository.UpdateAsync(SelectedBook);
                await UnitOfWorkEntity.ConmpleteAsync();
                Books.Clear();
                Books = temp;
                CopyBooks = Books;
            }
        }

        private BitmapImage ToImage(byte[] array)
        {
            using (var ms = new System.IO.MemoryStream(array))
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad; // here
                image.StreamSource = ms;
                image.EndInit();
                return image;
            }
        }
        public void AddUpdateBook(Book? book)
        {
            List<Book> temp = new List<Book>();
            bool IsUpdate = false;
            foreach (var item in Books)
            {
                if (item.Id == book.Id)
                {
                    temp.Add(book);
                    IsUpdate = true;
                }
                else
                temp.Add(item);
            }
            if (!IsUpdate)
                temp.Add(book);

            Books.Clear();
            Books = temp;
            CopyBooks = Books;
        }
        public void Load()
        {
            Books = UnitOfWorkDp.BookRepository.GetAll().ToList().FindAll(x=>x.IsActived==true);
            CopyBooks = Books;
            Customers = UnitOfWorkDp.CustomerRepository.GetAll().ToList().FindAll(x => x.IsActived == true);
            BookHistory = UnitOfWorkDp.BookTransactionRepository.GetAll().ToList().FindAll(x => x.IsActived == true);
        }
    }
}
