﻿using DataAccessLayer;
using Domains;
using GalaSoft.MvvmLight.CommandWpf;
using Library.SubEvent;
using Prism.Events;
using PropertyChanged;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace LibraryManagementSystem.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class CustomerCreationWindowVM:BaseVM
    {
        public Customer NewCustomer { get; private set; }

        private UnitOfWorkEntity UnitOfWork;

        public ICommand AddCustomerCmnd { get; set; }
        public IEventAggregator GetEventAggregator { get; set; }

        public event Action<object, RoutedEventArgs> CloseEvent;

        public CustomerCreationWindowVM(ContextEntity _context, IEventAggregator getEventAggregator)
        {
            UnitOfWork = new UnitOfWorkEntity(_context);
            NewCustomer = new Customer();
            AddCustomerCmnd = new RelayCommand(AddCustomerMethod);
            GetEventAggregator = getEventAggregator;
        }

        private async void AddCustomerMethod()
        {
                CloseEvent?.Invoke(new object(), new RoutedEventArgs());
                await UnitOfWork.CustomerRepository.AddAsync(NewCustomer);
                await UnitOfWork.ConmpleteAsync();
                GetEventAggregator.GetEvent<CustomerAddUpdateEvent>().Publish(NewCustomer);

        }
    }
}
