﻿using Domains;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace Library.SubEvent
{
    public class BookAddUpdateEvent:PubSubEvent<Book>
    {
    }
}
