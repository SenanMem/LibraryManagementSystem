﻿using Domains;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace Library.SubEvent
{
    public class HistorySendEvent : PubSubEvent<List<BookTransaction>>
    {
    }
}
