﻿using DataAccessLayer;
using Domains;
using Library.SubEvent;
using LibraryManagementSystem.ViewModels;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LibraryManagementSystem.Views
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : UserControl
    {
        private ContextEntity _context { get; set; }
        private ContextDapper _contextDp { get; set; }
        public HomeVM HomeVm { get; set; }
        public Book book { get; set; }
        public IEventAggregator GetEventAggregator { get; set; }
        public Home()
        {
            GetEventAggregator = new EventAggregator();
            _contextDp = new ContextDapper();
            _context = new ContextEntity();
            HomeVm = new HomeVM(_contextDp,_context, GetEventAggregator);
            this.DataContext = HomeVm;
            InitializeComponent();
        }

        private void UpdateBookBtn_Click(object sender, RoutedEventArgs e)
        {
            book = List_View.SelectedItem as Book;
            List_View.SelectedItem = null; //sebeb bu secilenden sonra o birine update edilerse eger
            if (book != null)
            {
                var newWindow = new BookUpdationWindow(_context, GetEventAggregator, book);
                newWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Not Selected data!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void HistoryBtn_Click(object sender, RoutedEventArgs e)
        {
            book = List_View.SelectedItem as Book;
            List_View.SelectedItem = null; //sebeb bu secilenden sonra o birine update edilerse eger
            if (book != null)
            {
                var newWindow = new BookHistoryWindow(_contextDp, GetEventAggregator, book);
                GetEventAggregator.GetEvent<HistorySendEvent>().Publish(HomeVm.BookHistory);
                newWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Not Selected data!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CheckOutBtn_Click(object sender, RoutedEventArgs e)
        {
            book = List_View.SelectedItem as Book;
            List_View.SelectedItem = null; //sebeb bu secilenden sonra o birine update edilerse eger
            if (book != null)
            {
                var newWindow = new CheckOutWindow(_context, GetEventAggregator, book);
                GetEventAggregator.GetEvent<HistorySendEvent>().Publish(HomeVm.BookHistory);
                GetEventAggregator.GetEvent<CustomersSendEvent>().Publish(HomeVm.Customers);
                newWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Not Selected data!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        } 

        private void CheckInBtn_Click(object sender, RoutedEventArgs e)
        {
            book = List_View.SelectedItem as Book;
            List_View.SelectedItem = null; //sebeb bu secilenden sonra o birine update edilerse eger
            if (book != null)
            {
                var newWindow = new CheckInWindow(_context, GetEventAggregator, book);
                GetEventAggregator.GetEvent<HistorySendEvent>().Publish(HomeVm.BookHistory);
                GetEventAggregator.GetEvent<CustomersSendEvent>().Publish(HomeVm.Customers);
                newWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Not Selected data!!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void AddBookBtn_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new BookCreationWindow(_context, GetEventAggregator);
            newWindow.ShowDialog();
        }

        private void CreateCustomerBtn_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new CustomerCreationWindow(_context, GetEventAggregator);
            newWindow.ShowDialog();
        }


        private void UpdateCustomerBtn_Click_1(object sender, RoutedEventArgs e)
        {
            var newWindow = new CustomerUpdationWindow(_context, GetEventAggregator);
            GetEventAggregator.GetEvent<CustomersSendEvent>().Publish(HomeVm.Customers);
            newWindow.ShowDialog();
        }

        private void DeleteCustomerBtn_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new CustomerDeletionWindow(_context, GetEventAggregator);
            GetEventAggregator.GetEvent<HistorySendEvent>().Publish(HomeVm.BookHistory);
            GetEventAggregator.GetEvent<CustomersSendEvent>().Publish(HomeVm.Customers);
            newWindow.ShowDialog();
        }
    }
}
