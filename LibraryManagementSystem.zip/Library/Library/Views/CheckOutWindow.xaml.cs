﻿using DataAccessLayer;
using Domains;
using LibraryManagementSystem.ViewModels;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagementSystem.Views
{
    /// <summary>
    /// Interaction logic for CheckOutWindow.xaml
    /// </summary>
    public partial class CheckOutWindow : Window
    {
        public CheckOutWindowVM WindowVM { get; set; }

        public CheckOutWindow(ContextEntity _context, IEventAggregator getEventAggregator, Book book)
        {
            WindowVM = new CheckOutWindowVM(_context, getEventAggregator, book);
            this.DataContext = WindowVM;
            WindowVM.CloseEvent += CancelBtn_Click;
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
