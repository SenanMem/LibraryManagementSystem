﻿using DataAccessLayer;
using Domains;
using Library.ViewModels;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagementSystem.Views
{
    /// <summary>
    /// Interaction logic for CheckInWindow.xaml
    /// </summary>
    public partial class CheckInWindow : Window
    {
        public CheckInWindowVM WindowVM { get; set; }

        public CheckInWindow(ContextEntity _context, IEventAggregator getEventAggregator, Book book)
        {
            WindowVM = new CheckInWindowVM(_context, getEventAggregator, book);
            this.DataContext = WindowVM;
            WindowVM.CloseEvent += CancelBtn_Click;
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
