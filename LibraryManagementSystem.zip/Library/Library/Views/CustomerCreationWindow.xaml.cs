﻿using DataAccessLayer;
using LibraryManagementSystem.ViewModels;
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryManagementSystem.Views
{
    /// <summary>
    /// Interaction logic for CustomerCreationWindow.xaml
    /// </summary>
    public partial class CustomerCreationWindow : Window
    {
        public CustomerCreationWindowVM WindowVM { get; set; }

        public CustomerCreationWindow(ContextEntity context, IEventAggregator getEventAggregator)
        {
            WindowVM = new CustomerCreationWindowVM(context,getEventAggregator);
            this.DataContext = WindowVM;
            WindowVM.CloseEvent += CancelBtn_Click;
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
