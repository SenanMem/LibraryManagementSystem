﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domains
{
    public class Book:BaseEntity
    {
        [Key]
        public int? Id { get; set; }
        public byte[] BookCover { get; set; }
        public string ISBN { get; set; }
        public string PlainISBN { get; set; }
        public string Title { get; set; }
        public string Authors { get; set; }
        public ushort PublishingYear { get; set; }
        public uint TotalCopies { get; set; } = 0;
        public uint AvailableCopies { get; set; } = 0;
        public uint TotalCheckOuts { get; set; } = 0;
        public override string ToString()
        {
            return $"{Id},{ISBN},{PlainISBN},{Title},{Authors},{PublishingYear},{TotalCopies},{AvailableCopies},{TotalCheckOuts}";
        }
    }
}
