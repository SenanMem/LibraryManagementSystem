﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domains
{
    public class BaseEntity
    {
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime? UpdateDate { get; set; }
        public DateTime? DeleteDate { get; set; }
        public bool IsActived { get; set; } = true;
    }
}
