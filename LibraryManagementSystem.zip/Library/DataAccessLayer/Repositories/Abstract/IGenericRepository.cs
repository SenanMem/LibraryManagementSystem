﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLayer.Repositories.Abstract
{
    public interface IGenericRepository<T> : IDisposable where T : new()
    {
        T GetById(int id);
        Task<T> GetByIdAsync(int id);

        IEnumerable<T> GetAll();
        Task<IEnumerable<T>> GetAllAsync();

        //IEnumerable<T> GetData(string qry, object parameters);
        //Task<IEnumerable<T>> GetDataAsync(string qry, object parameters);

        T Find(Expression<Func<T,bool>> predicate);
        Task<T> FindAsync(Expression<Func<T, bool>> predicate);

        IEnumerable<T> FindAll(Expression<Func<T, bool>> predicate);
        Task<IEnumerable<T>> FindAllAsync(Expression<Func<T, bool>> predicate);

        void Add(T entity);
        Task AddAsync(T entity);

        void AddRange(IEnumerable<T> entities);
        Task AddRangeAsync(IEnumerable<T> entities);

        void Remove(T entity);
        Task RemoveAsync(T entity);

        void Update(T entity);
        Task UpdateAsync(T entitys);
    }
}
