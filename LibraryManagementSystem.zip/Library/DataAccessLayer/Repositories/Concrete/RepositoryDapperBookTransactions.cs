﻿using Dapper;
using DataAccesLayer.Repositories.Abstract;
using Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories.Concrete
{
    public class RepositoryDapperBookTransactions : IGenericRepository<BookTransaction>
    {
        protected ContextDapper _context;
        private bool _disposed;
        private string _sqlCommand;
        public RepositoryDapperBookTransactions(ContextDapper context)
        {
            _context = context;
        }
        public IEnumerable<BookTransaction> GetAll()
        {
            _sqlCommand = $"SELECT * FROM BookTransactions bt INNER JOIN Customers c ON bt.CustomerId=c.Id INNER JOIN Books b ON bt.BookId=b.Id ";
            _context.Open();
            var bookTransactions = _context.Connection.Query<BookTransaction, Customer,Book, BookTransaction>(_sqlCommand, (bookTransaction, customer,book) => {
                bookTransaction.Customer = customer;
                bookTransaction.Book = book;
                return bookTransaction;
            });
            _context.Close();
            return bookTransactions;
        }

        public async Task<IEnumerable<BookTransaction>> GetAllAsync()
        {
            _sqlCommand = $"SELECT * FROM BookTransactions bt INNER JOIN Customers c ON bt.CustomerId=c.Id INNER JOIN Books b ON bt.BookId=b.Id ";
            await _context.OpenAsync();
            var bookTransactions = await _context.Connection.QueryAsync<BookTransaction, Customer, Book, BookTransaction>(_sqlCommand, (bookTransaction, customer, book) => {
                bookTransaction.Customer = customer;
                bookTransaction.Book = book;
                return bookTransaction;
            }); _context.Close();
            await _context.CloseAsync();
            return bookTransactions.ToList();
        }


        public void Add(BookTransaction entity)
        {
            throw new NotImplementedException();
        }

        public Task AddAsync(BookTransaction entity)
        {
            throw new NotImplementedException();
        }

        public void AddRange(IEnumerable<BookTransaction> entities)
        {
            throw new NotImplementedException();
        }

        public Task AddRangeAsync(IEnumerable<BookTransaction> entities)
        {
            throw new NotImplementedException();
        }

        public BookTransaction Find(Expression<Func<BookTransaction, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BookTransaction> FindAll(Expression<Func<BookTransaction, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<BookTransaction>> FindAllAsync(Expression<Func<BookTransaction, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public Task<BookTransaction> FindAsync(Expression<Func<BookTransaction, bool>> predicate)
        {
            throw new NotImplementedException();
        }


        public BookTransaction GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<BookTransaction> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public void Remove(BookTransaction entity)
        {
            throw new NotImplementedException();
        }

        public Task RemoveAsync(BookTransaction entity)
        {
            throw new NotImplementedException();
        }

        public void Update(BookTransaction entity)
        {
            throw new NotImplementedException();
        }

        public Task UpdateAsync(BookTransaction entitys)
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
