﻿using Dapper;
using DataAccesLayer.Repositories.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories.Concrete
{
    public class RepositoryDapper<TEntity> : IGenericRepository<TEntity> where TEntity : class,new()
    {
        protected ContextDapper _context;
        private Type typeOfObject;
        private bool _disposed;
        private string _sqlCommand;

        public RepositoryDapper(ContextDapper context)
        {
            var GetEntity = new TEntity();
            typeOfObject = GetEntity.GetType();
            _context = context;
        }

        public void Add(TEntity entity)
        {
            throw new NotImplementedException();
        }

        public Task AddAsync(TEntity entity)
        {
            throw new NotImplementedException();
        }

        public void AddRange(IEnumerable<TEntity> entities)
        {
            throw new NotImplementedException();
        }

        public Task AddRangeAsync(IEnumerable<TEntity> entities)
        {
            throw new NotImplementedException();
        }

        public TEntity Find(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }
        public Task<TEntity> FindAsync(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<TEntity> FindAll(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }
        public Task<IEnumerable<TEntity>> FindAllAsync(Expression<Func<TEntity, bool>> predicate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<TEntity> GetAll()
        {
            _sqlCommand = $"SELECT * FROM {typeOfObject.Name}s";
            _context.Open();
            var Entitys = _context.Connection.Query<TEntity>(_sqlCommand).ToList();
            _context.Close();
            return Entitys;
            //Orders o INNER JOIN Clients c ON o.clientId=c.Id INNER JOIN Jobs j ON o.JobTemplateId=j.Id INNER JOIN Task t ON o.taskId=t.Id
        }
        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            _sqlCommand = $"SELECT * FROM {typeOfObject.Name}s";
            await _context.OpenAsync();
            var Entitys = await _context.Connection.QueryAsync<TEntity>(_sqlCommand);
            await _context.CloseAsync();
            return Entitys;
        }

        public TEntity GetById(int id)
        {
            throw new NotImplementedException();
        }
        public Task<TEntity> GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public void Remove(TEntity entity)
        {
            throw new NotImplementedException();
        }
        public Task RemoveAsync(TEntity entity)
        {
            throw new NotImplementedException();
        }

        public void Update(TEntity entity)
        {
            throw new NotImplementedException();
        }
        public Task UpdateAsync(TEntity entitys)
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
