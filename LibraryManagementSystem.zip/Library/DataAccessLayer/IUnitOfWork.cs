﻿using DataAccesLayer.Repositories.Abstract;
using Domains;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public interface IUnitOfWork
    {
        public IGenericRepository<Book> BookRepository { get; }
        public IGenericRepository<Customer> CustomerRepository { get; }
        public IGenericRepository<BookTransaction> BookTransactionRepository { get; }
    }
}
