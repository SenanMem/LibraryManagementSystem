﻿using DataAccesLayer.Repositories.Abstract;
using DataAccessLayer.Repositories.Concrete;
using Domains;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public class UnitOfWorkDapper : IUnitOfWork
    {
        public IGenericRepository<Book> BookRepository { get; private set; }
        public IGenericRepository<Customer> CustomerRepository { get; private set; }
        public IGenericRepository<BookTransaction> BookTransactionRepository { get; private set; }

        public ContextDapper  _context;


        public UnitOfWorkDapper(ContextDapper context)
        {
            _context = context;
            BookRepository = new RepositoryDapper<Book>(_context);
            CustomerRepository = new RepositoryDapper<Customer>(_context);
            BookTransactionRepository = new RepositoryDapperBookTransactions(_context);
        }

    }
}
