﻿using DataAccesLayer.Repositories.Abstract;
using DataAccesLayer.Repositories.Concrete;
using Domains;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class UnitOfWorkEntity : IUnitOfWork
    {
        private ContextEntity _context;

        public UnitOfWorkEntity(ContextEntity context)
        {
            _context = context;
            BookRepository = new RepositoryEntity<Book>(_context);
            CustomerRepository = new RepositoryEntity<Customer>(_context);
            BookTransactionRepository = new RepositoryEntity<BookTransaction>(_context);
        }

        public IGenericRepository<Book> BookRepository { get; private set; }

        public IGenericRepository<Customer> CustomerRepository { get; private set; }

        public IGenericRepository<BookTransaction> BookTransactionRepository { get; private set; }

        public int Conmplete()
        {
            return _context.SaveChanges();
        }
        public async Task<int> ConmpleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
