﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class ContextDapper : IDisposable
    {
        public SqlConnection Connection { get; set; }
        public string ConnectionString { get; }
        public ContextDapper()
        {
            var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetParent(AppContext.BaseDirectory).FullName).AddJsonFile("AppSettings.json");
            var config = configuration.Build();
            ConnectionString = config.GetConnectionString("DefaultConnection");
            Connection = new SqlConnection();
            Connection.ConnectionString = ConnectionString;
        }

        public void Open()
        {
            Connection.Open();
        }
        public async Task OpenAsync()
        {
          await Connection.OpenAsync();
        }

        public void Close()
        {
            Connection.Close();
        }
        public async Task CloseAsync()
        {
            await Connection.CloseAsync();
        }

        public void Dispose()
        {
            Connection?.Dispose();
        }
        public async Task DisposeAsync()
        {
            await Connection.DisposeAsync();
        }
    }
}
